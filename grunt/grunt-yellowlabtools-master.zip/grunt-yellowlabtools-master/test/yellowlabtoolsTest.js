/*jshint -W030 */

'use strict';

var should              = require('chai').should();
var yellowlabtools      = require('../tasks/yellowlabtools');


/*describe('yellowlabtools task', function() {

    it('should launch multiple runs', function(done) {
        this.timeout(60000);

        done();
    });
});*/