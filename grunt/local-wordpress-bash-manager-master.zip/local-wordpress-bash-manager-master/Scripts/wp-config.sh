#! /bin/bash

# Path to your WordPress installs
# eg: Users/$USER/Desktop/sites
SITE_PATH="/Path/To/WordPress/Installs"

# Database information
DB_USER="root"
DB_PASS=""
DB_HOST="localhost"

# Site Data
ADMIN_USERNAME="admin"
ADMIN_PASSWORD="password"
ADMIN_EMAIL="admin@localhost.com"
TLD=".dev"
