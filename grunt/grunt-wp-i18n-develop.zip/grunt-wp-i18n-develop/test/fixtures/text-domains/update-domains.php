<?php
__( 'String', 'oldtextdomain' );
__( 'String', 'vendortextdomain' );
