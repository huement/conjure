<?php
/**
 * Template Name: Full Width
 */
