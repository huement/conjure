<?php
/**
 * Plugin Name: Example Plugin
 */

__( 'Exclude', 'plugin-include' );
