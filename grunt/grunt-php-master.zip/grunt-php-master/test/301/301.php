<?php echo '301 Redirected!' ?>
