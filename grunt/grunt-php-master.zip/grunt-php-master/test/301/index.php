<?php
	header('Location: 301.php', true, 301);
	exit;
?>
