<?php echo 'Hello World' ?>
