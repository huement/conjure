<?php header("HTTP/1.0 400 Bad Request"); ?>
<?php echo 'Hello World' ?>
