<?php header("HTTP/1.0 500 Internal Server Error"); ?>
<?php echo 'Hello World' ?>
