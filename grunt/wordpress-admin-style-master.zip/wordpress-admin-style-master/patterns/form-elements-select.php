<h2><?php esc_attr_e( 'Form Elements: Select', 'WpAdminStyle' ); ?></h2>

<select name="" id="">
	<option selected="selected" value="">Example option</option>
	<option value="">Example option</option>
</select>
