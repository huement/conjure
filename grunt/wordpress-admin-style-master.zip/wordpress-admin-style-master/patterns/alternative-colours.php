<h2><?php esc_attr_e( 'Alternative Colors', 'WpAdminStyle' ); ?></h2>

<div style="width:99%; padding: 5px;"><?php esc_attr_e( 'without class', 'WpAdminStyle' ); ?></div>
<div style="width:99%; padding: 5px;" class="alternate">class .alternate</div>
<div style="width:99%; padding: 5px;" class="alt">class .alt</div>
<div style="width:99%; padding: 5px;" class="form-invalid">class .form-invalid</div>
