<h2><?php esc_attr_e( 'Form Elements: Textarea', 'WpAdminStyle' ); ?></h2>

<textarea id="" name="" cols="80" rows="10">no class</textarea><br>
<textarea id="" name="" cols="80" rows="10" class="large-text">.large-text</textarea><br>
<textarea id="" name="" cols="80" rows="10" class="all-options">.all-options</textarea>
