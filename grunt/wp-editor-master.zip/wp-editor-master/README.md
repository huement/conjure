# [WP Editor](https://wpeditor.net) #
[![License](https://img.shields.io/badge/license-GPL--2.0%2B-red.svg)](https://github.com/easydigitaldownloads/Easy-Digital-Downloads/blob/master/license.txt)

### The way online code editors were meant to be made.

## Contributing

* Fork the repository on GitHub
* Make the changes to your forked repository
* When committing, reference your issue (if present) and include a note about the fix
* Push the changes to your fork and submit a pull request to the 'master' branch of the WP Editor repository