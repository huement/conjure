# CHANGELOG

# 1.1.0

- Fix grunt.fail.errorcount (thanks @bob-gray!): https://github.com/vigetlabs/grunt-complexity/pull/48

# 1.0.1

- Properly count maintainability score

# 1.0.0

- Support ES6 by switching to the `typhonjs-escomplex` variant. (Thanks, @kevde!)

# 0.4.0

- Throw a more detailed error message in event of an empty source file
(@skoblenick [91dc55f](https://github.com/vigetlabs/grunt-complexity/pull/37/commits/91dc55fa05eea28e78acac2882867c79cc21abc5))

# 0.3.1

- Escape PMD violation method names when reporting anonymous functions
  (@theoneroof [acfb4e4](https://github.com/theoneroof/grunt-complexity/commit/acfb4e49c363811eb1ee8bae76ebb74442161c76))
