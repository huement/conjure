module.exports = function() {
	if (true) {
		if (true) {
			if (true) {
				return false;
			}
		}
	}
};
