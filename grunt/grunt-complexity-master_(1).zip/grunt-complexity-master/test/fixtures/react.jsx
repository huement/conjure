import React from 'react'

class Message extends React.Component {
  render() {
    return <p>Test</p>
  }
}

export default Message
