## Status
[![NPM][badge-npm-image]][badge-npm-url]

[![Dependency Status][badge-gemnasium-image]][badge-gemnasium-url] [![Dependencies Status][badge-dependencies-image]][badge-dependencies-url] [![devDependencies Status][badge-dev-dependencies-image]][badge-dev-dependencies-url]

[![Bitdeli Badge][badge-bitdeli-image]][badge-bitdeli-url] [![xrefs][badge-sourcegraph-image]][badge-sourcegraph-url] [![Stories in Ready][badge-waffle-image]][badge-waffle-url] [![endorse][badge-endorse-image]][badge-endorse-url]