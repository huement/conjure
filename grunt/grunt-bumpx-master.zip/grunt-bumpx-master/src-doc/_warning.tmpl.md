### Compatibility Issues

**As of v0.2.0+, this plugin is no longer backwards compatible with older versions (0.1.x). If you decide to update your version to the latest, be sure to update your configuration files or Grunt will spit on you for sure.**