## License
See the [LICENSE][] distributed with the project.