# <%= meta.name %> [![GitHub version][badge-github-version-image] ][badge-github-version-url] [![Built with Grunt][badge-grunt-image] ][badge-grunt-url]
> <%= meta.description %>