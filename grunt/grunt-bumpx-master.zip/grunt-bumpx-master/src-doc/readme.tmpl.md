<%= partials.header %>

<%= partials.status %>

<%= partials.getting_started %>

<%= partials.the_task %>

<%= partials.warning %>

<%= partials.options %>

<%= partials.cli %>

<%= partials.examples %>

<%= partials.contributing %>

<%= partials.donating %>

<%= partials.history %>

<%= partials.license %>

<%= partials.links %>