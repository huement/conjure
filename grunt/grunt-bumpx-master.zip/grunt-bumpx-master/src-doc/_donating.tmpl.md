## Donating
If you like this work, please consider to support its future development:

[![Gittip][badge-gittip-image]][badge-gittip-url] [![Flattr this][badge-flattr-image]][badge-flattr-url]

[![I Love Open Source][badge-open-source-image]][badge-open-source-url]

BTC: `19ZEWBKuTzNw1opsEN95pG6JuAxuDYq3Nq`

LTC: `LNoFqJJAM195B4GnNq45JtsWDNtkb8h8WR`


Thanks!
