
var path = require("path");

module.exports = function(grunt) {
  grunt.loadTasks(path.join(__dirname, "services"));
};
