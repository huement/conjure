## Example project using `grunt-aws`

* Create a `aws-credentials.json` file like:

    ``` json
    {
      "accessKeyId": "...",
      "secretAccessKey": "..."
    }
    ```

* `npm install`

* `grunt`