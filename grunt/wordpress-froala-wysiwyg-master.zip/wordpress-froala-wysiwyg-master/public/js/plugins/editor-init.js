//Don't delete me
// This file is required to load inline javascript using wardress functions.