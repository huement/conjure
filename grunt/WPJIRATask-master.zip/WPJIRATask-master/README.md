# WPJIRATask
A script to check your Wordpress install and create a JIRA task if it is out of date.

## Script
You need to fill in the variables in wpjira.sh with your Wordpress URL, JIRA URL, JIRA username and JIRA password.

*Note:* I need to figure out a better way to pause this script so it doesn't create multiple tickets. So far I just pause the script for a week if it out of date and run it hourly if it isnt.

## Important Notice
*I likely dont know what I am doing and this could be done faster, better and simpler some other way. These scripts could also break your Jira install and make you cry.*
