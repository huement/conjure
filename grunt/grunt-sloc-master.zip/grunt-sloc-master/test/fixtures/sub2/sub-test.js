var zoo = function() {
	return 33;
}