//comment
function gSloc() {
	return false;
}

var bar = 33;