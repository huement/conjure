<?php

/**
 * Underscore JS template for the Modal window tabs.
 *
 * @package Tailor
 * @subpackage Underscore Templates
 * @since 1.0.0
 */

defined( 'ABSPATH' ) or die(); ?>

<script id="tmpl-tailor-modal-item" type="text/html">
    <h3><%= title %></h3>
</script>