var EmptyPanelView = Marionette.ItemView.extend( {

    className : 'empty',

    template : '#tmpl-tailor-home-empty'

} );

module.exports = EmptyPanelView;