var EmptySectionView = Marionette.ItemView.extend( {

    className : 'empty',

    template : '#tmpl-tailor-section-default-empty'

} );

module.exports = EmptySectionView;