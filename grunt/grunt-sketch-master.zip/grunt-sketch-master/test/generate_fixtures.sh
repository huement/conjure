#!/usr/bin/env bash

sketchtool export slices fixtures/Grunt\ Logo.sketch --output=fixtures/generated --items=Grunt\ Logo,Symbol,Text --formats=png,jpg --scales=1,2