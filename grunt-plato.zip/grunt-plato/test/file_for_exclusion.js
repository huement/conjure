"use strict";

(function() {
  var a = 1;
})();
