'use strict';

module.exports = require('pa11y-lint-config/eslint/es6');
