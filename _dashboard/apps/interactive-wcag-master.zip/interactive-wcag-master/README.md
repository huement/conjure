# Interactive WCAG

A filterable and shareable version of the WCAG 2.0 spec.

## Contents

1. [Requirements](#requirements)
2. [Installation](#installation)
3. [Developing](#developing)
4. [Resources](#resources)

## Requirements

- [Node](http://nodejs.org/)
- [Grunt](http://gruntjs.com/)

## Installation

### Install Grunt packages

From the root of the site and run `npm install`.

## Developing

### Grunt

- Run `grunt` to do a one-time compile of all the assets to the `dest` directory.
- Run `grunt watch` while working on the project to compile assets as they're modified.

### Local Server

In the second tab run `grunt connect` and go to:<br>
[http://0.0.0.0:8000/](http://0.0.0.0:8000/)

### Production

Run a production build to inline the dependent JS and CSS with `grunt deploy`.

## View on Github Pages

[http://vigetlabs.github.io/interactive-wcag/](http://vigetlabs.github.io/interactive-wcag/)

## Resources

- [W3C Recommendation](http://www.w3.org/TR/WCAG20/)
- [WebAIM's WCAG 2.0 Checklist](http://webaim.org/standards/wcag/checklist)

***

<a href="http://code.viget.com">
  <img src="http://code.viget.com/github-banner.png" alt="Code At Viget">
</a>

Visit [code.viget.com](http://code.viget.com) to see more projects from [Viget.](https://viget.com)
