<?php

/**
 *
 * PHP version 5
 *
 * Created: 12/16/15, 5:45 PM
 *
 * LICENSE: MIT
 *
 *
 * @author         Jeff Behnke <code@validwebs.com>
 * @copyright  (c) 2015 ValidWebs.com
 *
 * dashboard
 * 404.php
 */
?>
<h2>404 page not found.</h2>

<h3>Sorry that page does not exist.</h3>

<p><a href="./">Return to Dashboard</a></p>
<?php
// End 404.php