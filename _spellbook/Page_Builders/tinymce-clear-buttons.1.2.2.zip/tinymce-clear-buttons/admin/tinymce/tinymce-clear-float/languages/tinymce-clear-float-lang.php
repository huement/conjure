<?php

$strings = 'tinyMCE.addI18n(
	"' . _WP_Editors::$mce_locale . '.tinymce_clear_float", {
		tooltip: "' . esc_js( __( 'Clear float', 'tinymce-clear-buttons' ) ) . '",
		img_title: "' . esc_js( __( 'Clear float', 'tinymce-clear-buttons' ) ) . '",
	}
)';
