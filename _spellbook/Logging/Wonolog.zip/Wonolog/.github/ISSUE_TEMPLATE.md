<!--
Thanks for contributing&mdash;you rock!

Please note:
- These comments won't show up when you submit the issue.
- Please choose a descriptive title (e.g., "Typo in readme").
- Almost everything is optional, but please try to provide as many details as possible.
- If requesting a new feature, please explain why you'd like to see it added.
-->

#### Version Information

* PHP: 
* WordPress: 

#### Steps to Reproduce

1. 
1. 
1. 

#### What I Expected



#### What Happened Instead

