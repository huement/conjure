<li>
	<a href="#" class="btn-project-assign" data-id="{{=id}}">
		{{=title}}
	</a>
</li>