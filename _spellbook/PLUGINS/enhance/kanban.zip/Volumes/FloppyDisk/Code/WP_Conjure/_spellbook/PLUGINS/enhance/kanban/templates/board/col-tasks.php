<div class="col col-sm-3 col-tasks" id="status-<?php echo $status_id ?>-tasks" data-status-id="<?php echo $status_id ?>">
</div><!-- col -->