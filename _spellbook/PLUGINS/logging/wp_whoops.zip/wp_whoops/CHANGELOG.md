# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).
This change log adheres to [Keep a CHANGELOG](http://keepachangelog.com/).

## Unreleased

## 1.1 - 2017-10-27

### Added
- WP REST API handler

### Changed
- Updated dependencies (whoops 2.1.12, Pimple 3.2.2)

## 1.0 - 2016-05-08

### Added
- Initial stable release.