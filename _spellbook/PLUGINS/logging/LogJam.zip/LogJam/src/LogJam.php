<?php

class LogJam
{
	const DEFAULT_LEVEL = self::INFO;
	const TRACE = 'trace';
	const DEBUG = 'debug';
	const INFO = 'info';
	const WARN = 'warn';
	const ERROR = 'error';
	const FATAL = 'fatal';
}
