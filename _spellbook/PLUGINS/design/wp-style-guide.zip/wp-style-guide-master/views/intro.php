<?php
/**
 * The intro
 */

?><section class="top-section">
	<p class="guide-desc"><?php esc_html_e( 'This page is a guide the mark-up styles used on this site.', 'wp-style-guide' ); ?></p>
