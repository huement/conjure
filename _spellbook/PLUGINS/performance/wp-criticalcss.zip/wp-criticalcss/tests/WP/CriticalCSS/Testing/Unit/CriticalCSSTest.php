<?php

namespace WP\Testing\Unit;

use WP\CriticalCSS;

class CriticalCSSTest extends CriticalCSS\Testing\Unit\TestCase {
	public function test_wp_criticalcss() {
		$instance = \wp_criticalcss();

		$this->assertInstanceOf( '\WP\CriticalCSS', $instance );
	}

	public function test_wp_head_with_nocache() {
		\WP_Mock::userFunction( 'get_query_var', [
			'args'   => 'nocache',
			'times'  => 1,
			'return' => true,
		] );
		ob_start();
		wp_criticalcss()->get_frontend()->wp_head();
		$result = ob_get_clean();
		$this->assertEquals( '<meta name="robots" content="noindex, nofollow"/>', trim( $result ) );
	}

	public function test_wp_head_without_nocache() {
		\WP_Mock::userFunction( 'get_query_var', [
			'args'   => 'nocache',
			'times'  => 1,
			'return' => false,
		] );
		ob_start();
		wp_criticalcss()->get_frontend()->wp_head();
		$result = ob_get_clean();
		$this->assertEmpty( $result );
	}

	public function test_redirect_canonical_with_nocache_query_var() {
		$GLOBALS['wp_query'] = (object) [
			'query' => [
				'nocache' => true,
				'test'    => true,
			],
		];
		\WP_Mock::userFunction( 'get_query_var', [
			'args'   => 'nocache',
			'times'  => 1,
			'return' => true,
		] );
		\WP_Mock::userFunction( 'home_url', [
			'times'  => 1,
			'return' => 'http://example.org',
		] );
		$this->assertFalse( wp_criticalcss()->get_request()->redirect_canonical( home_url() ) );
	}

	public function test_query_vars() {
		$this->assertContains( 'nocache', wp_criticalcss()->get_request()->query_vars( [] ) );
	}

	public function test_get_settings() {
		wp_criticalcss()->get_settings_manager()->update_settings( $this->assssfo ->update_settings( $this->assssfo gs() {
	dnd:VERSION ticalcss>assertEmnager()->update_settings( $this->assssfo -gs( $thialcss()->get_requIb_grnalTyp)->  =rayion st_redirectss()->get_requNonction t  =rayion st_redirectings() {
		wp_criticalcss()->get_sett_etion ache', wp_criticalcction tnager()->update_segs( $this->asssssegs( $thiirectings() {
		wp_criticalcssiest_prin->gtyles_hook_adminet_query_var', [
			'args'   => is_admin' => ck::userFunction ticalcsnager()->update_seiest(e_url', [
			'texp

	As'   NonAdded=> nagprin->gtyles' => 'htnager()->update_org',
prin->gtyles' criticalcings() {
		wp_criticalcssiest_tetildatep_queronet_query_var', [
			'args'   => is_admin' => ck::userFunccriti ticalcsnager()->update_settings( $this->assssfo ->update_settings( $ttetildatep_que
		$thasssticalcsnager()->update_seiest(e_url/*rl', [
			'texp

	As'   Added=> tetildateinclude' => 'htcsnager()->update_settin

	public];
		\	 tetildateinclude' ;
		\], PHP_INT_MAXica*/lcings() {
		wp_criticalcssiest_tetildatep_queroffings_manager()->update_settings( $this->assssfo ->update_settings( $ttetildatep_que
		$thaffssticalcsy_var', [
			'args'   => is_admin' => ck::userFunccriti ticalcs', [
			'texp

	As'   Added=> pocss>updatd' => 'htnager()->update_settinp_quer->assssfoorg',
		_se_web_queck_pocsstransi $r'( 'home_url', [
			'texp

	As'   Added=> ;
	atd_term' => 'htnager()->update_settinp_quer->assssfoorg',
		_se_web_queck_termstransi $r'( 'home_urlnager()->update_settinp_quer->assssfoseiest(e_urings() {
		wp_criticalcss()->permalink_pocset_query_var', [
			'args'   => 'nocpermalink	'times'  => 1,
			'.org',
		] );
		$this->assertFalse( w/equest(/'( 'home_url', [
			't			'args'   =rg',
		_tortepurr $r_blog' => 'htctp://exa		'.org',]rg'rectsspermalinktEmnager()->update_settinpermalink(=> 'httpyp)ck::u
			'rpocs=> truecache'_idxa		'.org'ticalcss()->get_requNonest()->spermalinktcalcss()->get_requss()->get_request(/ion permalinktcalcings() {
		wp_criticalcss()->permalink_termet_query_var', [
			'args'   => 'noctermslink	'times'  => 1,
			'.org',
		] );
		$this->assertFalse( w/taw/tlcs/equest(/'( 'home_url', [
			't			'args'   =rg',
		_tortepurr $r_blog' => 'htctp://exa		'.org',]rg'rectsspermalinktEmnager()->update_settinpermalink(=> 'httpyp)ck::u
			'rterm'  truecache'_idxa		'.org'ticalcss()->get_requNonest()->spermalinktcalcss()->get_requss()->get_request(/ion permalinktcalcings() {
		wp_criticalcss()->permalink_aurFuret_query_var', [
			'args'   = true()->aurFur_pocssturn' => 'ht'  => 1,
			'.org',,
		] );
		$this->assertFalse( w/aurFur/admin/equest(/'( 'h,]rg'rects', [
			't			'args'   =rg',
		_tortepurr $r_blog' => 'htctp://exa		'.org',]rg'rectsspermalinktEmnager()->update_settinpermalink(=> 'httpyp)ck::u
			'raurFur'  truecache'_idxa		'.org'ticalcss()->get_requNonest()->spermalinktcalcss()->get_requss()->get_request(/ion permalinktcalcings() {
		wp_criticalcss()->permalink_est_ququery_var', [
			'args'   = true	'return' => 'htttp://example.org',tart();
		wp_cp_critic(n tepuwp_h{;
		\	rt();
this->assertFalse( wp .n tepuw;;
		\}( 'h,]rg'rects', [
			't			'args'   =rg',
		_tortepurr $r_blog' => 'htctp://exa		'.org',]rg'rectsspermalinktEmnager()->update_settinpermalink(rg',> 'htctpyp)ck		'rurn'  'htcturn'ampleion test_ '/tlcsabc/tlcsabc/tlcsabc/' )org',]rg'rectss()->get_requNonest()->spermalinktcalcss()->get_requss()->get_request(/ion permalinktcalcings(rothe'ed_cp_critic_seUp_ququerpar $r::_seUp_q_urlnager()->update_segs( $this->assssse>update_settings( ome_url', [
			't			'args'   =rg',
is_admin' =>rg',tart();
		wp_criticalc,]rg'rectsnager()->update_seiest(e_uring}
