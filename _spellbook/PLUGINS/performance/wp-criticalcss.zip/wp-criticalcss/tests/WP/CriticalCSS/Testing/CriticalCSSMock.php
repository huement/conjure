<?php


namespace WP\CriticalCSS\Testing;


use WP\CriticalCSS;

class CriticalCSSMock extends CriticalCSS {


}