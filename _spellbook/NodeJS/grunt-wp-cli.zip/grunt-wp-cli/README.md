# grunt-wp-cli
Grunt wrapper for wp-cli
