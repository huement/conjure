<?php
/**
 * Plugin Name: Example Plugin
 * Domain Path: /languages
 * Text Domain: example-plugin
 */
