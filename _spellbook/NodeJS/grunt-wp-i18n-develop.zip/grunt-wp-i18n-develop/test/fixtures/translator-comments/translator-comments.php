<?php
/**
 * Plugin Name: Translator Comments
 */

/* translators: A single line translators comment. */
__( 'A' );

/*
 * translators: A
 * multiline
 * translators
 * comment.
 */
__( 'B' );
