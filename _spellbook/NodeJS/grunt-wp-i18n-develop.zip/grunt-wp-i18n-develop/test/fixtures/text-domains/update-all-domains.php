<?php
__( 'String' );
__( 'String', 'oldtextdomain' );
__( 'String', 'vendortextdomain' );
date( 'F j, Y', time() );
_x( 'String', 'a string' );
_x( 'String', 'a string', 'oldtextdomain' );
_x( 'String', 'a string', 'vendortextdomain' );
_n( '1 Star', '%s Stars', 2 );
_n( '1 Star', '%s Stars', 2, 'oldtextdomain' );
_n( '1 Star', '%s Stars', 2, 'vendortextdomain' );
