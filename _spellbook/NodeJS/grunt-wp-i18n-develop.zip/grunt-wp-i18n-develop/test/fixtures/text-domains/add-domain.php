<?php
__( 'String' );
