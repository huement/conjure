<?php
/**
 * PHPUnit bootstrap file
 *
 * @package Advanced_Cron_Manager
 */

require_once( dirname( __DIR__ ) . '/vendor/autoload.php' );

WP_Mock::bootstrap();
