<?php
/**
 * Searchbox part
 */
?>

<div class="searchbox">
	<input type="search" id="search" placeholder="<?php _e( 'Search events...', 'advanced-cron-manager' ); ?>" class="widefat">
</div>
