export const getSelectedVersion = state => state.ui.version;

export const getSelectedApi = state => state.ui.api;
