export const getVersions = ( state, apiName ) => state.versions[ apiName ] || [];
