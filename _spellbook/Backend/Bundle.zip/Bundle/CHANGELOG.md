### 1.0.1: 11th February 2017
* Add YAML and PHP file support

### 1.0.0: 07th January 2017
* Release Bundle
