<?php

namespace Sober\Bundle;

use Noodlehaus\AbstractConfig;

class ConfigNoFile extends AbstractConfig
{

}