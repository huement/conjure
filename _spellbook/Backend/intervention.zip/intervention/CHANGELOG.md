### 1.2.0: 22nd August 2017
* New; Add custom-html, media-image, media-audio, media-video, akismet to remove-widgets module
* New: Add AddMenuPage

### 1.1.1: 06th February 2017
* Bug; add-svg-support to support WordPress 4.7.1+ bug. 
* Change; Add new label attributes for posts and pages when being renamed
* Change; Merge Roles.php into Instance.php
* Change; Change Labels to a triat

### 1.1.0: 02nd November 2016
* Feature; Remove default from add-dashboard-redirect so that a custom route can be applied.
* New; remove-customizer-items to help remove sections and controls from Customizer.

### 1.0.2: 26th September 2016
* Bug; Remove 'Add New' from default singular label.

### 1.0.1: 22nd September 2016
* Rewrite; Move to OOPHP and use PSR-4 autoloading.
* Bug; Fix module remove-menu-items for Advanced Custom Fields top level menu item.
* Docs; Add DocBlocks for lib classes.

### 1.0.0: 12th September 2016
* Let's get this intervention started.
