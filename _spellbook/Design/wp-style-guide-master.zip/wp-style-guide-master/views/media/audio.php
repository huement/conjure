<?php
/**
 * Audio
 */

?><div class="style-item" id="audio">
	<h3 class="item-title"><?php esc_html_e( 'Audio', 'wp-style-guide' ); ?></h3>
	<p class="item-description"></p>
	<span class="item-example"></span>
</div><!-- End of style item -->
