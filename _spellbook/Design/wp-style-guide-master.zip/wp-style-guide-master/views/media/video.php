<?php
/**
 * Video
 */

?><div class="style-item" id="video">
	<h3 class="item-title"><?php esc_html_e( 'Video', 'wp-style-guide' ); ?></h3>
	<p class="item-description"></p>
	<span class="item-example"></span>
</div><!-- End of style item -->
