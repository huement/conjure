<?php if(get_sub_field('title')): ?>
    <header class="block-title">
    	<div class="block-title-inner">
    		<?php the_block_title(); ?>
    	</div>
    </header>
<?php endif; ?>
