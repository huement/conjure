<?php if(get_sub_field('title')): ?>
    <header class="collapsibles-title">
    	<div class="collapsibles-title-inner">
    		<h4><?php the_sub_field('title'); ?></h4>
    	</div>
    </header>
<?php endif; ?>
