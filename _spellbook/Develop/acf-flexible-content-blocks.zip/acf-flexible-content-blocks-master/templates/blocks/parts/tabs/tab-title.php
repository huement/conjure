<?php if(get_sub_field('title')): ?>
    <header class="tab-title">
    	<div class="tab-title-inner">
    		<h3><?php the_sub_field('title'); ?></h3>
    	</div>
    </header>
<?php endif; ?>
