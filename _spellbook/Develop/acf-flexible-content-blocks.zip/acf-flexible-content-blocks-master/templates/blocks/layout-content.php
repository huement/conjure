<?php cfb_template('blocks/parts/block-content', get_row_layout()); ?>
