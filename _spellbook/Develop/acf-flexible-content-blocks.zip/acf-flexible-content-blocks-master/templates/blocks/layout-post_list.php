<?php cfb_template('blocks/parts/block-content', get_row_layout()); ?>
<?php cfb_template('blocks/parts/block-post_list', get_row_layout()); ?>
