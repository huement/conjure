<?php cfb_template('blocks/parts/block-content', get_row_layout()); ?>
<?php cfb_template('blocks/parts/collapsibles/collapsibles-panels', get_row_layout()); ?>
