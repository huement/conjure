<?php cfb_template('blocks/parts/block-media', get_row_layout()); ?>
<?php cfb_template('blocks/parts/block-cta', get_row_layout()); ?>
