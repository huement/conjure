<?php cfb_template('blocks/parts/block-content', get_row_layout()); ?>
<?php cfb_template('blocks/parts/block-slider', get_row_layout()); ?>
