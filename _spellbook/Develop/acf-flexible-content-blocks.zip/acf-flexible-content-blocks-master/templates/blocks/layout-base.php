
<section class="<?php fcb_block_wrapper_classes(); ?>" style="<?php fcb_block_wrapper_styles(); ?>">
    <div class="<?php fcb_block_classes(); ?>">
        <div class="block-inner">

            <?php cfb_template('blocks/parts/block-title', get_row_layout()); ?>
            <?php cfb_template('blocks/layout', get_row_layout()); ?>

        </div> <!-- /block-inner -->
    </div> <!-- /block -->
</section> <!-- /block-wrap -->
