<figure class="block-addon block-figure">
	<?php cfb_template('blocks/parts/media/media-gallery', get_row_layout()); ?>
</figure>

