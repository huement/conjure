<?php

/* MAIL TRAPPING */
define('WPG_MAIL_TRAPPING', serialize([wpg_local('DEV_MAIL')]));
