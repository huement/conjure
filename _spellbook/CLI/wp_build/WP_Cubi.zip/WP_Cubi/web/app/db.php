<?php

if (file_exists(WP_PLUGIN_DIR . '/query-monitor/wp-content/db.php')) {
    include_once(WP_PLUGIN_DIR . '/query-monitor/wp-content/db.php');
}
