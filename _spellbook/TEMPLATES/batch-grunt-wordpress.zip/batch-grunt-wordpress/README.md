# batch-grunt-wordpress
An automated workflow for WordPress builds
