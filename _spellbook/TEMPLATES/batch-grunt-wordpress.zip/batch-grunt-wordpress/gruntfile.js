module.exports = function(grunt) {

	// Load all tasks
	require('load-grunt-tasks')(grunt);

	grunt.initConfig({

		// Make JSON files available
		pkg: grunt.file.readJSON('package.json'),
		project: grunt.file.readJSON('project.json'),

		// Construct stylesheet header
		header: '/*\n' +
		'Theme Name: <%= project.client %> <%= project.year %>\n' +
		'Author: <%= project.author.name %>\n' +
		'Author URI: <%= project.author.website %>\n' +
		'Description: The <%= project.year %> WordPress theme for <%= project.client %> \n' +
		'Version: <%= project.version %>\n\n' +
		'Last Updated: <%= grunt.template.today("dd-mm-yyyy") %>\n' +
		'*/',

		// Add banners to files
		usebanner: {
			dist: {
				options: {
					position: 'top',
					banner: '<%= header %>'
				},
				src: '<%= project.build.directory %>/style.css'
			}
		},

		// Clean files and folders
		clean: {
			options: { 
				force: true 
			},
			build: '<%= project.build.directory %>',
		},

		// Compile Sass to CSS
		sass: {
			build: {
				options: {
					style: 'compressed',
				},
				src: 'src/assets/scss/main.scss',
				dest: '<%= project.build.directory %>/style.css'
			},
			options: {
				sourcemap: 'none',
			}
		},

		// Add vendor-prefixed CSS properties
		autoprefixer: {
			options: {
				browsers: '<%= pkg.browserslist %>'
			},
			build: {
				src: '<%= project.build.directory %>/style.css',
				dest: '<%= project.build.directory %>/style.css'
			}
		},

		// Concatenate Javascript files
		concat: {
			options: {
				separator: ';',
			},
			build: {
				src: '<%= project.jsFiles %>',
				dest: 'src/assets/js/common.js',
			}
		},

		// Minify Javascript files
		uglify: {
			options: {
				mangle: false,
				preserveComments: 'some'
			},
			build: {
				files: [{
					expand: true,
					cwd: 'src/assets/js',
					src: ['**/*.js', '!**/common/**'],
					dest: '<%= project.build.directory %>/assets/js',
					rename: function(dest, src) {
						if (src.indexOf('.min.js') > -1 ) { // If it has a .min.js extension already, don't modify
							return dest + '/' + src;
						} else { // Otherwise add a .min.js extension
							return dest + '/' + src.replace('.js', '.min.js');
						}					
					}
				}]
			}
		},

		// Minify images
		imagemin: {
			dist: {
				files: [{
					expand: true,
					cwd: 'src/assets/img',
					src: ['**/*.{png,jpg,gif}'],
					dest: 'src/assets/img'
				}]
			}
		},

		// Copy files and folders
		copy: {
			images: {
				files: [{
					expand: true,
					cwd: 'src/assets',
					src: ['img/**'],
					dest: '<%= project.build.directory %>/assets',
				}]
			},
			templates: {
				files: [{
					expand: true,
					cwd: 'src/templates',
					src: ['**'],
					dest: '<%= project.build.directory %>',
				}]
			},
			other: {
				files: [{
					expand: true,
					cwd: 'src',
					src: ['*'],
					dest: '<%= project.build.directory %>',
					filter: 'isFile'
				}, {
					expand: true,
					cwd: 'src/assets',
					src: ['webfonts/**'],
					dest: '<%= project.build.directory %>/assets',
				}, {
					expand: true,
					cwd: 'src/assets/favicons',
					src: ['**'],
					dest: '<%= project.build.directory %>/assets/favicons',
				}]
			},
		},

		// Open URLs and files 
		open: {
			dist: {
				path: '<%= project.build.directory %>',
			}
		},

		// Run tasks whenever watched files change
		watch: {
			sass: {
				files: ['src/assets/scss/**/*.scss'],
				tasks: ['sass:build', 'autoprefixer:build', 'usebanner:dist']
			},
			php: {
				files: ['src/templates/**/*.php'],
				tasks: ['copy:templates']
			},
			twig: {
				files: ['src/templates/**/*.twig'],
				tasks: ['copy:templates']
			},
			js: {
				files: ['src/assets/js/**/*.js'],
				tasks: ['concat', 'uglify']
			},
			img: {
				files: ['src/assets/img/**/*'],
				tasks: ['copy:images']
			},
			options: {
				livereload: true
			},
		},

	});

	// Task definitions
	grunt.registerTask('build', ['clean:build', 'sass:build', 'autoprefixer:build', 'usebanner:dist', 'concat', 'uglify', 'copy:templates', 'copy:images', 'copy:other' ]);
	grunt.registerTask('dist', ['clean:build', 'sass:build', 'autoprefixer:build', 'usebanner:dist', 'concat', 'uglify', 'imagemin:dist', 'copy:templates', 'copy:images', 'copy:other', 'open']);
	grunt.registerTask('test', []);
	grunt.registerTask('default', ['build', 'watch']);

};